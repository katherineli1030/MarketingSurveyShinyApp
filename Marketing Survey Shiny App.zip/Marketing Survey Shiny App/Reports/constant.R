# constant based on the mobile phone survey data set
id.name <- "id"
age.name <- "age_group"
gender.name <- "Gender"
income.name <- "income_group"
region.name <- "Region"
persona.name <- "Persona"
product.name <- "Product"

awareness.name <- "Awareness"
consideration.name <-"Consideration"
consumption.name <-"Consumption"
satisfaction.name <-"Satisfaction"
advocacy.name <-"Advocacy"

aggregate.engagement <- "aggregate_engagement"
respondent.variables <- c(age.name,gender.name,income.name,region.name,persona.name)
states.of.engagement <- c(awareness.name, consideration.name, consumption.name, satisfaction.name, advocacy.name)
bp.pattern <- "BP_"